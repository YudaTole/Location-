const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const axios = require("axios");
const fs = require("fs");

const API_KEY = "YOUR_OPENCAGE_API_KEY"; // Ganti dengan API Key asli kamu dari https://opencagedata.com/

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log('connection closed due to', lastDisconnect.error, ', reconnecting', shouldReconnect);
      if (shouldReconnect) startBot();
    } else if (connection === 'open') {
      console.log('Bot tersambung!');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const sender = msg.key.remoteJid;

    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    // Jika user ketik "lokasi" → bot minta share lokasi
    if (text && text.toLowerCase() === "lokasi") {
      await sock.sendMessage(sender, {
        text: "📍 Silakan kirim lokasi kamu melalui tombol 📎 lalu pilih 'Lokasi'."
      });
    }

    // Jika user kirim lokasi
    if (msg.message.locationMessage) {
      const lat = msg.message.locationMessage.degreesLatitude;
      const lon = msg.message.locationMessage.degreesLongitude;

      let locationName = "Tidak diketahui";
      try {
        const response = await axios.get(`https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lon}&key=${API_KEY}`);
        const results = response.data.results;
        if (results.length > 0) {
          locationName = results[0].formatted;
        }
      } catch (error) {
        console.error("Gagal mengambil nama lokasi:", error.message);
      }

      // Simpan ke file lokal
      const log = `${new Date().toISOString()} - ${sender} - ${lat},${lon} - ${locationName}\n`;
      fs.appendFileSync("lokasi_log.txt", log);

      await sock.sendMessage(sender, {
        text: `📍 Lokasi diterima:
Latitude: ${lat}
Longitude: ${lon}
🗺️ Lokasi: ${locationName}

🔗 Google Maps:
https://www.google.com/maps?q=${lat},${lon}`
      });
    }
  });
}

startBot();
